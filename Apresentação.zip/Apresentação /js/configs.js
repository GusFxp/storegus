document.body.style.overflowX = "hidden";
